
Spinning Wait Icons by Andrew Davidson
http://andrewdavidson.com/articles/spinning-wait-icons/

These icons are licensed under a 
Creative Commons Attribution-NonCommercial-ShareAlike 2.5 License.

You are free to copy, distribute, display, and perform the work
to make derivative works under the following conditions:

Attribution. You must attribute the work in the manner specified by the author or licensor.
Noncommercial. You may not use this work for commercial purposes.
Share Alike. If you alter, transform, or build upon this work, you may distribute the resulting work only under a license identical to this one.

For any reuse or distribution, you must make clear to others the license terms of this work.
Any of these conditions can be waived if you get permission from the copyright holder.

Your fair use and other rights are in no way affected by the above.

View the full license here:
http://creativecommons.org/licenses/by-nc-sa/2.5/

